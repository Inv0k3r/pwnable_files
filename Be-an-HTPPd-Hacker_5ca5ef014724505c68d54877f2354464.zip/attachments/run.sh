#!/bin/sh
cd /home && ./httpd 12345
