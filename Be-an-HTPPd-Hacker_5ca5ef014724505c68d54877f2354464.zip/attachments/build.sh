#!/bin/sh

docker build -t httpd .
