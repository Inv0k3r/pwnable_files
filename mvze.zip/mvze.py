codes = open("binary", "rb").read()
reg_list = {
    0: 'rax',
    1: 'rbx',
    2: 'rcx',
    3: 'rdx'
}
for i in range(len(codes) // 12):
    code = codes[i*12:i*12+12]
    instrument = int.from_bytes(code[0:4], 'little')
    data1 = int.from_bytes(code[4:8], 'little')
    data2 = int.from_bytes(code[8:12], 'little')
    print("{:3}. {} -> ".format(i, hex(int.from_bytes(code, 'little'))[2:].rjust(24, '0')), end='')

    if instrument == 0:
        print("push {}".format(data1), end='')

    if instrument == 1:
        print("push {}".format(reg_list[data1]), end='')
    
    if instrument == 2:
        print("pop {}".format(reg_list[data1]), end='')

    if instrument == 3: # mov
        if data1 >= 32 and data1 <= 126:
            char = chr(data1)
        else:
            char = '\\x' + hex(data1)[2:].rjust(2, '0')
        print("mov {}, {}({})".format(reg_list[data2], hex(data1), char), end='')
    
    if instrument == 4:
        print("mov {}, data[{}]".format(reg_list[data2], data1), end='')
    
    if instrument == 5:
        print("add {}, {}".format(reg_list[data2], reg_list[data1]), end='')
    
    if instrument == 6:
        print("sub {}, {}".format(reg_list[data2], reg_list[data1]), end='')
    
    if instrument == 7:
        print("mul {}, {}".format(reg_list[data2], reg_list[data1]), end='')
    
    if instrument == 8:
        print("div {}, {}".format(reg_list[data2], reg_list[data1]), end='')

    if instrument == 9:
        print("xor {}, {}".format(reg_list[data2], reg_list[data1]), end='')
    
    if instrument == 10:
        print("mov {}, {}".format(reg_list[data2], reg_list[data1]), end='')

    if instrument == 11: # 
        print("mov data[{}], {}".format(data2, reg_list[data1]), end='')
    
    if instrument == 12:
        print("mov data[{}], {}".format(reg_list[data2], reg_list[data1]), end='')
    
    if instrument == 13:
        print("inc {}".format(reg_list[data1]), end='')
    
    if instrument == 14:
        print("dec {}".format(reg_list[data1]), end='')
    
    if instrument == 15:
        print("cmp {}, {}".format(data2, reg_list[data1]), end='')
    
    if instrument == 16:
        print("cmp {}, {}".format(reg_list[data2], reg_list[data1]), end='')
    
    if instrument == 17:
        print("jl code[{}]".format(data1), end='')
    
    if instrument == 18:
        print("push {}; call code[{}]".format(data2, data1), end='')
    
    if instrument == 19:
        print("push rbp", end='')
    
    if instrument == 20:
        print("mov rbp, rsp", end='')
    
    if instrument == 21:
        print("mov rsp, rbp", end='')
    
    if instrument == 22:
        print("pop rbp", end='')
    
    if instrument == 23:
        print("pop rip, ret", end='')

    if instrument == 24:
        print("mov [rsp-{}], {}".format(((~data1+1)&0xffffffff), reg_list[data2]), end='')
    
    if instrument == 25:
        print("add {}, {}".format(reg_list[data2], data1), end='')
    
    if instrument == 26:
        print("sub {}, {}".format(reg_list[data2], data1, end=''))
    
    if instrument == 27:
        print("mov {}, data[{}]".format(reg_list[data2], reg_list[data1]), end='')
    
    if instrument == 28:
        print("mov data[{}], {}".format(reg_list[data2], reg_list[data1]), end='')
    
    if instrument == 29:
        print("jne code[{}]".format(data1), end='')
    
    if instrument == 30:
        print("jmp code[{}]".format(data1), end='')
    
    if instrument == 50:
        print("in  rax(int)", end='')
    
    if instrument == 51:
        print("out rax(int)", end='')

    if instrument == 52:
        print("out rax(char)", end='')
    
    if instrument == 53:
        print("in rax(char)", end='')
    
    if instrument == 54:
        print("hlt", end='')
    
    print()